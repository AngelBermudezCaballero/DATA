# Tareas - Aplicación de Gestión de Tareas


Descripción 

Este programa permite gestionar tareas a través de una interfaz de línea de comandos (CLI), proporcionando operaciones CRUD (Crear, Leer, Actualizar y Eliminar) sobre las tareas. Además, se incluye persistencia de datos en archivos JSON y CSV.

Requisitos

Antes de ejecutar el programa, asegúrate de tener instalados los siguientes módulos de Python:

colorama

Puedes instalarlos utilizando el siguiente comando:

pip install colorama

Estructura del Proyecto

```
├── main/
│   ├── main.py
│   └── README.md
├── models/
│   ├── __init__.py
│   ├── gestor.py
│   ├── menu.py
│   ├── persistencia.py
│   └── tarea.py
├── .venv/
└── tareas.json
└── tareas.csv
```

Ejecución del Programa

Para ejecutar el programa, sigue estos pasos:

Abre una terminal y navega al directorio que contiene el archivo main.py.

Ejecuta el programa usando Python:

python main/main.py

Esto iniciará el programa y te mostrará el menú principal.

Interfaz de Usuario

Una vez que inicies el programa, verás el siguiente menú:

--------- Menu ---------
1. Add new note
2. Display all notes
3. Search for a note by title
4. Search for a note by content
5. Update a note
6. Delete a note
0. Exit

Enter your choice:

Opciones del Menú

Agregar una tarea nueva: Permite al usuario agregar una nueva tarea ingresando el título, la descripción y la prioridad (baja, media o alta).

Mostrar todas las tareas: Muestra la lista de todas las tareas registradas.

Buscar una tarea por título: Permite al usuario buscar una tarea ingresando su título exacto.

Buscar una tarea por contenido: Permite al usuario buscar tareas que contengan una palabra clave en la descripción.

Actualizar una tarea: Permite al usuario editar una tarea, cambiando su título, descripción o prioridad.

Eliminar una tarea: Permite al usuario eliminar una tarea de la lista.

Salir: Finaliza el programa.

Ejemplo de uso:

Agregar tarea:

Ingrese el título de la tarea: Comprar alimentos

Ingrese la descripción de la tarea: Pan, leche, huevos, etc.

Ingrese la prioridad. Las opciones son: baja / media / alta: media

Mostrar tareas:

Lista de tareas:
[comprar alimentos] Pan, leche, huevos, etc. - Prioridad: media

Persistencia de Datos

El programa guarda y carga las tareas en dos formatos:

JSON: Las tareas se guardan y cargan desde un archivo JSON (tareas.json).

CSV: Además, las tareas se guardan en formato CSV (tareas.csv) cuando se cierra el programa.