from models.menu import Menu
from models.gestor import GestorTareas


def main():
    # Crear una instancia de GestorTareas
    # gestor = GestorTareas()
    gestor = GestorTareas()

    # Crear una instancia de Menu
    menu = Menu(gestor)

    # Llamar al para mostrar el menu
    menu.mostrar_menu()


if __name__ == "__main__":
    main()
