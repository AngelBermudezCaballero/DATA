from colorama import Fore, Style, init

# Inicializamos Colorama para que los colores se reseteen, lo que significa que después del primer
# print con color, los siguientes prints volverán al color normal.
init(autoreset=True)

class Tarea:
    def __init__(self, titulo: str, descripcion: str, prioridad: str):
        self.titulo = titulo.strip().lower()
        self.descripcion = descripcion
        self.prioridad = prioridad  # "baja", "media" o "alta"

    def __str__(self):
        prioridad_coloreado = {
            "baja": Fore.BLUE + self.prioridad + Style.RESET_ALL,  # en azul
            "media": Fore.YELLOW + self.prioridad + Style.RESET_ALL,  # en amarillo
            "alta": Fore.RED + self.prioridad + Style.RESET_ALL  # en rojo
        }.get(self.prioridad, self.prioridad)  # Si no coincide se deja sin color

        return f"[{self.titulo}] {self.descripcion} - Prioridad: {prioridad_coloreado}"
