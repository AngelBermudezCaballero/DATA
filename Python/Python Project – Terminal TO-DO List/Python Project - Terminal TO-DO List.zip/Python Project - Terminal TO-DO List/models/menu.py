import os
import time

class Menu:
    def __init__(self, gestor):
        self.gestor = gestor

    def limpiar_terminal(self):
        os.system('cls' if os.name == 'nt' else 'clear')

    def esperar(self):
        input("\nPress Enter to continue...")  # Para que le dé tiempo al usuario a leer el mensaje

    def mostrar_menu(self):
        while True:
            self.limpiar_terminal()  # Limpiar la terminal al mostrar el menú
            print("--------- Menu ---------")
            print("1. Add new note")
            print("2. Display all notes")
            print("3. Search for a note by title")
            print("4. Search for a note by content")
            print("5. Update a note")
            print("6. Delete a note")
            print("0. Exit")

            opcion = input("Enter your choice: ").strip()

            if opcion == '1':
                self.gestor.agregar_tarea()
                self.esperar()
            elif opcion == '2':
                self.gestor.mostrar_tareas()
                self.esperar()
            elif opcion == '3':
                self.gestor.buscar_por_titulo()
                self.esperar()
            elif opcion == '4':
                self.gestor.buscar_por_descripcion()
                self.esperar()
            elif opcion == '5':
                self.gestor.editar_tarea()
                self.esperar()
            elif opcion == '6':
                self.gestor.eliminar_tarea()
                self.esperar()
            elif opcion == '0':
                print("\nGoodbye!")
                self.gestor.cerrar_programa()  # Guardamos las tareas en CSV antes de cerrar
                break
            else:
                print("\nInvalid option. Please choose a valid option (0-6).")
                time.sleep(2)  # Pausa antes de limpiar y mostrar el menú nuevamente



