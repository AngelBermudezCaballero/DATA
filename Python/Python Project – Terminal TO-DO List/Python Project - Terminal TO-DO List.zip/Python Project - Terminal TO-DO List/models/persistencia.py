import json
import csv
from models.tarea import Tarea

ARCHIVO_JSON = "tareas.json"
ARCHIVO_CSV = "tareas.csv"

def guardar_tareas_json(tareas):
    with open(ARCHIVO_JSON, "w", encoding="utf-8") as archivo:
        json.dump([{"titulo": i.titulo, "descripcion": i.descripcion, "prioridad": i.prioridad} for i in tareas], archivo, indent=4)
        # paso un objeto Tarea a diccionario, lo guardo en archivo y sangria

def cargar_tareas_json():
    try:
        with open(ARCHIVO_JSON, "r", encoding="utf-8") as archivo:
            datos = json.load(archivo)
            return [Tarea(t["titulo"], t["descripcion"], t["prioridad"]) for t in datos]
            # convertimos cada diccionario a nuestra instancia de la clase tarea es decir en un objeto Tarea
    except (FileNotFoundError, json.JSONDecodeError):
        return []
        # con esto lo que hago es que en caso de que haya algun error(archivo vacío o formato incorrecto) devuelve una lista vacía y siga funcionando

def guardar_tareas_csv(tareas):
    with open(ARCHIVO_CSV, "w", newline="", encoding="utf-8") as archivo:
        campos = ["titulo", "descripcion", "prioridad"]
        escritor_csv = csv.DictWriter(archivo, fieldnames=campos)
        # fieldnames define las claves o cabeceras de las columnas
        escritor_csv.writeheader()
        for i in tareas:
            escritor_csv.writerow({"titulo": i.titulo, "descripcion": i.descripcion, "prioridad": i.prioridad})
        # convierto cada objeto Tarea en un diccionario y lo guarda en un archivo CSV.

def cargar_tareas_csv():
    tareas = []
    try:
        with open(ARCHIVO_CSV, "r", newline="", encoding="utf-8") as archivo:
            lector_csv = csv.DictReader(archivo)
            for fila in lector_csv:
                tareas.append(Tarea(fila["titulo"], fila["descripcion"], fila["prioridad"]))
    except FileNotFoundError:
        return []
    return tareas

# csv.DictReader() no devuelve una lista normal de diccionarios.
# Es un objeto que se comporta como un diccionario fila por fila.
# Debemos recorrerlo (con el for) y convertir cada fila en un objeto Tarea.
