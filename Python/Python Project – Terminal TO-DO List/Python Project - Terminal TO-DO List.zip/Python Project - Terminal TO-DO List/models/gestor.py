from models.persistencia import *

class GestorTareas:

    def __init__(self):

        self.tareas = cargar_tareas_csv()  # Cargar tareas desde CSV al inicio

    #1:

    def agregar_tarea(self):
        while True:  # Se repite hasta que se introduzca un título diferente
            titulo = input("Ingrese el título de la tarea: ").strip().lower()

            existe = False
            for i in self.tareas:
                if i.titulo == titulo:
                    print("\n Error: Ya existe una tarea con ese título. Inténtelo de nuevo.")
                    existe = True
                    break  # Salimos del bucle for, pero no del while

            if not existe:
                break  # Salimos del while

        descripcion = input("Ingrese la descripción de la tarea: ").strip()
        prioridad = input("Ingrese la prioridad. Las opciones son: baja / media / alta: ").strip().lower()

        nueva_tarea = Tarea(titulo, descripcion, prioridad)  # Eliminado "estado", ya que no está en la clase Tarea
        self.tareas.append(nueva_tarea)
        guardar_tareas_json(self.tareas)  # Guardar en JSON después de modificar
        print("\n La tarea ha sido agregada con éxito.")

    #2:

    def mostrar_tareas(self):
        if len(self.tareas) == 0:
            print("\n No hay tareas registradas.")
        else:
            print("\n Lista de tareas:")
            for i in self.tareas:
                print(i)

    #3:

    def buscar_por_titulo(self):

        self.mostrar_tareas()

        while True:
            titulo = input("\n Ingrese el título exacto de la tarea que desea buscar: ").strip().lower()

            for i in self.tareas:
                if i.titulo == titulo:
                    print("\n Tarea encontrada:")
                    print(i)  # Se imprime la tarea
                    return   #nos salimos del metodo si se imprime con exito

            print("\n Error: No se encontró una tarea con ese título. Inténtelo de nuevo.")

    #4:

    def buscar_por_descripcion(self):

        self.mostrar_tareas()

        while True:
            palabra_clave = input("\n Ingrese una palabra clave para buscar en la descripción: ").strip().lower()
            tareas_encontradas = []  # Lista vacía para almacenar coincidencias

            # Recorrer la lista de tareas y buscar coincidencias
            for i in self.tareas:
                if palabra_clave in i.descripcion.lower():
                    tareas_encontradas.append(i)  # Agregar la tarea a la lista tareas_encontradas

            if tareas_encontradas:
                print("\n Tarea/Tareas encontradas:")
                for i in tareas_encontradas:
                    print(i)
                return  #nos salimos del metodo si se encuentra alguna/algunas tareas

            print("\n Error: No se encontraron tareas que contengan esa palabra. Inténtelo de nuevo.")

    #5:

    def editar_tarea(self):

        self.mostrar_tareas()

        while True:
            titulo = input("\n Ingrese el título exacto de la tarea que desea editar: ").strip().lower()

            for i in self.tareas:
                if i.titulo == titulo:
                    print("\n Tarea encontrada:")
                    print(i)

                    nuevo_titulo = input("\n Nuevo título: ").strip().lower()
                    nueva_descripcion = input("Nueva descripción: ").strip()
                    nueva_prioridad = input("Nueva prioridad. Las opciones son: baja / media / alta: ").strip().lower()

                    i.titulo = nuevo_titulo
                    i.descripcion = nueva_descripcion
                    i.prioridad = nueva_prioridad
                    guardar_tareas_json(self.tareas)  # Guardar en JSON después de modificar

                    print("\n La tarea ha sido editada y actualizada con éxito.")
                    return  #nos salimos del metodo si se edita con exito

            print("\n Error: No se encontró una tarea con ese título. Inténtelo de nuevo.")

    #6:

    def eliminar_tarea(self):

        self.mostrar_tareas()

        while True:
            titulo = input("\n Ingrese el título exacto de la tarea que desea eliminar: ").strip().lower()

            for i in self.tareas:
                if i.titulo == titulo:
                    self.tareas.remove(i)  # Eliminamos tarea
                    guardar_tareas_json(self.tareas)  # Guardar en JSON después de modificar
                    print("\n La tarea ha sido eliminada con éxito.")
                    return  #nos salimos del metodo si se elimina con exito

            print("\n Error: No se encontró una tarea con ese título. Inténtelo de nuevo.")

    def cerrar_programa(self):
        guardar_tareas_csv(self.tareas)  # Guardar en CSV antes de cerrar
